import React from 'react';

const PoliciesPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">Vehicle Insurance Policies</h1>
      <p className="text-lg mb-8">
        Below are the policies available for vehicle insurance. Please review
        them carefully before making a decision.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {/* Example policy card */}
        <div className="bg-white shadow-lg rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-2">Standard Policy</h2>
          <p className="text-gray-600 mb-4">
            Our standard policy offers basic coverage for your vehicle.
          </p>
          <ul className="list-disc list-inside">
            <li>Liability coverage</li>
            <li>Collision coverage</li>
            <li>Comprehensive coverage</li>
          </ul>
          <button className="bg-blue-500 text-white px-4 py-2 mt-4 rounded hover:bg-blue-600 transition duration-300">
            Get a Quote
          </button>
        </div>

        {/* Add more policy cards here */}
      </div>
    </div>
  );
};

export default PoliciesPage;
