import Form from 'react-bootstrap/Form';
import { Link } from 'react-router-dom';

function Formpage() {
  return (
   
    <>
      

   

    </>
    
  );
}

export default Formpage;