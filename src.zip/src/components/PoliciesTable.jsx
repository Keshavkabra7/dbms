import React from 'react';

function InsuranceTable() {
  const carPolicies = [
    {
      id: 1111101,
      policyName: 'Bajaj car insurance cover1',
      description: ['This policy provides coverage for damage to your own vehicle caused by accidents, theft, vandalism, natural disasters, and other unforeseen events. It offers extensive protection beyond just collisions, giving you peace of mind on the road.', "PIP covers medical expenses, lost wages, and other accident-related costs for you and your passengers, regardless of fault. It's especially beneficial for covering immediate medical needs and ensuring financial stability after an injury"],
      type: '1st person',
      pricing: 9999
    },
    {
      id: 1111102,
      policyName: 'Bajaj car insurance cover2',
      description: 'This policy covers damages and injuries you cause to other people and their property in an accident. It\'s essential for meeting legal requirements and protecting your financial assets from lawsuits if you\'re at fault in a collision.',
      type: '3rd party',
      pricing: 2499
    }
  ];

  const bikePolicies = [
    {
      id: 1111201,
      policyName: 'Bajaj Bike insurance cover1',
      description: 'This policy provides comprehensive protection for your motorcycle against various risks, including accidents, theft, vandalism, natural disasters, and more. It ensures that you\'re financially covered for damages to your bike in a wide range of situations.',
      type: '1st person',
      pricing: 1999
    },
    {
      id: 1111202,
      policyName: 'Bajaj Bike insurance cover2',
      description: 'This policy covers the costs of damages and injuries you cause to others and their property while riding your motorcycle. It\'s essential for meeting legal requirements and protecting yourself from financial liabilities in case of accidents.',
      type: '3rd party',
      pricing: 799
    }
  ];

  const truckPolicies = [
    {
      id: 1111301,
      policyName: 'Mobility truck insurance',
      description: ['This policy provides comprehensive protection for your truck against various risks, including accidents, theft, vandalism, natural disasters, and more. It ensures that you\'re financially covered for damages to your truck in a wide range of situations.', 'This policy covers the costs of damages and injuries you cause to others and their property while driving your truck. It\'s essential for meeting legal requirements and protecting yourself from financial liabilities in case of accidents.'],
      type: '1st person',
      pricing: 14999
    }
  ];

  return (
    <div>
      <h2>Car Policies</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Policy Name</th>
            <th>Description</th>
            <th>Type</th>
            <th>Pricing (per year)</th>
          </tr>
        </thead>
        <tbody>
          {carPolicies.map(policy => (
            <tr key={policy.id}>
              <td>{policy.id}</td>
              <td>{policy.policyName}</td>
              <td>
                <ul>
                  {Array.isArray(policy.description) ? policy.description.map((desc, index) => <li key={index}>{desc}</li>) : <li>{policy.description}</li>}
                </ul>
              </td>
              <td>{policy.type}</td>
              <td>{policy.pricing} rs</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Bike Policies</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Policy Name</th>
            <th>Description</th>
            <th>Type</th>
            <th>Pricing (per year)</th>
          </tr>
        </thead>
        <tbody>
          {bikePolicies.map(policy => (
            <tr key={policy.id}>
              <td>{policy.id}</td>
              <td>{policy.policyName}</td>
              <td>{policy.description}</td>
              <td>{policy.type}</td>
              <td>{policy.pricing} rs</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Truck Policies</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Policy Name</th>
            <th>Description</th>
            <th>Type</th>
            <th>Pricing (per year)</th>
          </tr>
        </thead>
        <tbody>
          {truckPolicies.map(policy => (
            <tr key={policy.id}>
              <td>{policy.id}</td>
              <td>{policy.policyName}</td>
              <td>
                <ul>
                  {policy.description.map((desc, index) => <li key={index}>{desc}</li>)}
                </ul>
              </td>
              <td>{policy.type}</td>
              <td>{policy.pricing} rs</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default InsuranceTable;
